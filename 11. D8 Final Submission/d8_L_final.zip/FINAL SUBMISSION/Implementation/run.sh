#!/bin/bash
java -jar InternManagement.jar
