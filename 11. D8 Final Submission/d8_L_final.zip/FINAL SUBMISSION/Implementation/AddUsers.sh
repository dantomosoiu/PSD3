#change input.csv to specify an input file
java bin/UserLoader userdata/input.csv
