package uk.ac.glasgow.internman.users;

/**
 * Enum for Role status
 * 
 * @author Team L
 *
 */
public enum Status {
	APPROVED, WITHDRAWN, PENDING
}
